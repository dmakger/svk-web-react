export const SMALL_SIZE = 'small'
export const LARGE_SIZE = 'large'